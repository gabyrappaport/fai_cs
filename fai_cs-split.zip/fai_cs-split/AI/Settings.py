HUMANS = "humans"
VAMPIRES = "vampires"
WAREWOLVES = "warewolves"